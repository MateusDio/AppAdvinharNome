package com.example.aulatelas

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val btn_telaDetalhes = findViewById<Button>(R.id.btn_TelaDetalhes)

      val edNome = findViewById<TextView>(R.id.txtNome)
        val edIdade = findViewById<TextView>(R.id.txtIdade)


        btn_telaDetalhes.setOnClickListener {
            val nome = edNome.text.toString()
            val idade = edIdade.text.toString()

            val intent = Intent(this, DetalhesActivity::class.java)

           intent.putExtra("nome", "Mateus")
            intent.putExtra("idade", 17)
            startActivity(intent)

        }


    }

}